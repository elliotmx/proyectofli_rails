//=require jquery-fileupload/vendor/jquery.ui.widget
//=require jquery-fileupload/jquery.iframe-transport
//=require jquery-fileupload/jquery.fileupload
;